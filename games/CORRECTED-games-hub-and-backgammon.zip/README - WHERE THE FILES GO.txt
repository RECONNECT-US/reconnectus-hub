CORRECT FILE LOCATIONS
======================

1. games/index.html
   This is the Games Hub page with all the tiles:
   Money Builder, Clock Learning, Word Search, Ball Sort,
   Draughts & Chess, and Backgammon.

2. games/backgammon/index.html
   This is the Backgammon game itself.

Keep both files named index.html.
Do not move the Backgammon index into the main games folder.

The finished website structure should be:

games/
  index.html                  <- Games Hub and tiles
  backgammon/
    index.html                <- Backgammon game

